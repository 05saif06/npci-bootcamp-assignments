package com.npci.thymeleaf.product;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class ThymeLeafProductApplicationTests {

	@Test
	void contextLoads() {
	}

}
